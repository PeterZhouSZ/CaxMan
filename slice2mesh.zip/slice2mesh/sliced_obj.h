#ifndef SLICED_OBJ_H
#define SLICED_OBJ_H

#include <sys/types.h>
#include <cinolib/meshes/trimesh/drawable_trimesh.h>

#include "slice.h"


class SlicedObj : public std::vector<Slice>
{
    public:

        SlicedObj(){}
        SlicedObj(const char * filename, const double machine_precision);

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        const Slice & slice(const int layer) const;
              Slice & slice(const int layer);

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        int    n_layers() const;
        double layer_thickness(const int l) const;

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        DrawableTrimesh<> export_wireframe_for_debug() const;

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        DrawableTrimesh<> triangulate() const;

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        void append_lid();
};

std::ostream & operator<<(std::ostream & in, const SlicedObj & obj);

#endif // SLICED_OBJ_H
