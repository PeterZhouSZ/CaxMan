#ifndef CLI_TO_VOL_DEBUG_H
#define CLI_TO_VOL_DEBUG_H

#include "edge_processing.h"

std::ostream & operator<<(std::ostream & in, const E_data & e);

#endif // CLI_TO_VOL_DEBUG_H
