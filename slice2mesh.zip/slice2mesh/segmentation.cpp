#include "segmentation.h"
#include "filter_plc.h"
#include "common.h"
#include "tiny_chart_helper.h"

#include <cinolib/bfs.h>


void detect_connected_components(const cinolib::Trimesh<> & plc, const int label, std::vector< std::vector<uint> > & ccs)
{
    // mask all the triangles having different label...
    std::vector<bool> mask(plc.num_faces());
    for(uint fid=0; fid<plc.num_faces(); ++fid) mask.at(fid) = (plc.face_data(fid).label != label);

    // find a legal seed (any triangle with the right label)
    uint seed = 0;
    while (seed < plc.num_faces() && mask.at(seed)) ++seed;
    assert(seed < plc.num_faces());

    do
    {
        std::set<uint> cc;
        cinolib::bfs_exahustive_on_dual<cinolib::Trimesh<>>(plc, seed, mask, cc);

        ccs.push_back(std::vector<uint>(cc.begin(), cc.end()));
        for(uint fid : cc) mask.at(fid) = true; // mask the visited triangles

        seed = 0;
        while (seed < plc.num_faces() && mask.at(seed)) ++seed; // get a new legal seed, if any
    }
    while (seed < plc.num_faces());
}

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

void detect_tiny_charts(       cinolib::Trimesh<>                 & plc,
                        const double                             area_thresh,
                              std::vector< std::vector<uint> > & tiny_charts)
{
    std::vector< std::vector<uint> > ccs;
    detect_connected_components(plc, SRF_FACE_UP,   ccs);
    detect_connected_components(plc, SRF_FACE_DOWN, ccs);

    std::vector<uint> bad_stuff;

    for(auto cc : ccs)
    {
        double area = 0.0;
        for(uint fid : cc) area += plc.face_area(fid);
        assert(cc.size() > 0);

        if (area < area_thresh)
        {
            std::cout << "tiny protuberance found! (" << cc.size() << " tris - area: " << area << ")" << std::endl;

            tiny_charts.push_back(cc);

            std::vector<uint> tmp;
            for(uint fid : cc)
            {
                tmp.push_back(plc.face_vert_id(fid,0));
                tmp.push_back(plc.face_vert_id(fid,1));
                tmp.push_back(plc.face_vert_id(fid,2));
            }
            std::copy(tmp.begin(), tmp.end(), std::back_inserter(bad_stuff));

            TinyChartHelper helper(plc, cc);
            plc = helper.push_chart_inside_PLC();
        }
    }

    cinolib::Trimesh<> m(plc.vector_coords(), bad_stuff);
    m.save("/Users/cino/Desktop/bad_stuff.off");
}
