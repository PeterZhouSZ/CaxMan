#include "filter_plc.h"
#include "common.h"


cinolib::Trimesh<> filter_PLC_by_label(const cinolib::Trimesh<> & plc,
                                             int                   legal_labels)
{
    std::vector<double> coords;
    std::vector<uint>   tris;
    filter_PLC_by_label(plc, legal_labels, coords, tris);
    return cinolib::Trimesh<>(coords, tris);
}



void filter_PLC_by_label(const cinolib::Trimesh<>  & plc,
                               int                   legal_labels,
                               std::vector<double> & coords,
                               std::vector<uint>   & tris)
{
    assert(tris.empty() && coords.empty());

    for(uint fid=0; fid<plc.num_faces(); ++fid)
    {
        if (plc.face_data(fid).label & legal_labels)
        {
            tris.push_back(plc.face_vert_id(fid,0));
            tris.push_back(plc.face_vert_id(fid,1));
            tris.push_back(plc.face_vert_id(fid,2));
        }
    }

    // TODO: remove unreferenced vertices (if any) and re-index the whole PLC!!!!
    coords = plc.vector_coords();
}
