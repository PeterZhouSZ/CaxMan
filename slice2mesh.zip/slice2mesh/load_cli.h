#ifndef LOAD_CLI_H
#define LOAD_CLI_H

#include "slice.h"

void load_CLI(const char * filename, const double machine_precision, std::vector<Slice> & slices);

#endif // LOAD_CLI_H
